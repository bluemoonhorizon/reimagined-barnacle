<?php 
ini_set('session.auto_start', 1);
//includes
$droot = $_SERVER['DOCUMENT_ROOT'];
//require_once("$droot/pages/antibotcloud/v2/security/session_manager.php");
session_start();
function randomClassId() {
$bytes = random_bytes(5); //random. Increase input for more bytes
$code = bin2hex($bytes);
return $code;
}
function get_random_values($file) {
if($file == 'html') {
   unset($_SESSION['overlay_container']);
   $_SESSION['overlay_container'] = randomClassId();
   //session_write_close();
}
return $_SESSION['overlay_container'];
}
//session write close 
//session_write_close();
?>
